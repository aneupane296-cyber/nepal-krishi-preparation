export type Commission = 'all' | 'federal' | 'koshi' | 'madhesh' | 'bagmati' | 'gandaki' | 'lumbini' | 'karnali' | 'sudurpashchim';
export type PostLevel = 'officer' | 'jt';
export type TabKey = 'home' | 'notes' | 'exam' | 'skill';

export interface StudyModule {
  id: string;
  title: string;
  category: string;
  content: string;
  tags: string[];
}

export interface MCQ {
  id: string;
  commission: Commission;
  postLevel: PostLevel;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export const COMMISSIONS: { value: Commission; label: string }[] = [
  { value: 'all', label: 'All Federal & Provinces' },
  { value: 'federal', label: 'Federal PSC (लोक सेवा आयोग)' },
  { value: 'koshi', label: 'Koshi Province' },
  { value: 'madhesh', label: 'Madhesh Province' },
  { value: 'bagmati', label: 'Bagmati Province' },
  { value: 'gandaki', label: 'Gandaki Province' },
  { value: 'lumbini', label: 'Lumbini Province' },
  { value: 'karnali', label: 'Karnali Province' },
  { value: 'sudurpashchim', label: 'Sudurpashchim Province' },
];

export const POST_LEVELS: { value: PostLevel; label: string }[] = [
  { value: 'officer', label: 'Officer 7th/8th Level' },
  { value: 'jt', label: 'JT/JTA 4th/5th Level' },
];
