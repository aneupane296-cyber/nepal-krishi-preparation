import { ChevronDown } from 'lucide-react';
import { COMMISSIONS, POST_LEVELS } from '@/types';
import type { Commission, PostLevel } from '@/types';

interface FilterBarProps {
  commission: Commission;
  postLevel: PostLevel;
  onCommissionChange: (c: Commission) => void;
  onPostLevelChange: (p: PostLevel) => void;
}

export function FilterBar({ commission, postLevel, onCommissionChange, onPostLevelChange }: FilterBarProps) {
  return (
    <div className="mx-auto max-w-2xl px-4 py-3">
      <div className="grid grid-cols-2 gap-2.5">
        <SelectField
          label="Commission / Province"
          value={commission}
          options={COMMISSIONS}
          onChange={(v) => onCommissionChange(v as Commission)}
        />
        <SelectField
          label="Post Level"
          value={postLevel}
          options={POST_LEVELS}
          onChange={(v) => onPostLevelChange(v as PostLevel)}
        />
      </div>
    </div>
  );
}

interface SelectFieldProps {
  label: string;
  value: string;
  options: { value: string; label: string }[];
  onChange: (v: string) => void;
}

function SelectField({ label, value, options, onChange }: SelectFieldProps) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-forest-300">{label}</span>
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full appearance-none rounded-xl border border-forest-100 bg-white px-3 py-2.5 pr-9 text-sm font-medium text-forest-600 shadow-sm transition-colors focus:border-forest-400 focus:outline-none focus:ring-2 focus:ring-forest-200"
        >
          {options.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
        <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-forest-300" />
      </div>
    </label>
  );
}
