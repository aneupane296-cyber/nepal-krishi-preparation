import { ExternalLink, ShieldCheck, FileText, AlertTriangle, Heart } from 'lucide-react';
import { Modal } from './Modal';
import { CREATOR_NAME } from '@/config';

interface InfoModalProps {
  open: boolean;
  onClose: () => void;
}

export function InfoModal({ open, onClose }: InfoModalProps) {
  return (
    <Modal open={open} onClose={onClose} title="Info & Policies">
      <div className="space-y-5">
        <section className="rounded-xl bg-forest-50 p-4">
          <div className="mb-2 flex items-center gap-2">
            <Heart className="h-4 w-4 text-amber-500" />
            <h3 className="text-sm font-bold text-forest-600">Creator</h3>
          </div>
          <p className="text-sm text-forest-400">
            This app was created by <span className="font-semibold text-forest-600">{CREATOR_NAME}</span> as a free
            educational tool for Nepal agriculture exam aspirants.
          </p>
        </section>

        <section className="rounded-xl bg-cream p-4">
          <div className="mb-2 flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-forest-400" />
            <h3 className="text-sm font-bold text-forest-600">Copyright-Free / Open Domain</h3>
          </div>
          <p className="text-sm text-forest-400">
            All study content in this app is original, government-published, or in the public domain. The Constitution
            of Nepal, Acts, and ADS documents are official government publications freely accessible to the public.
            This app is free to use and share.
          </p>
        </section>

        <section className="rounded-xl bg-cream p-4">
          <div className="mb-2 flex items-center gap-2">
            <FileText className="h-4 w-4 text-forest-400" />
            <h3 className="text-sm font-bold text-forest-600">Google AdSense Privacy Policy</h3>
          </div>
          <p className="text-sm text-forest-400">
            This app displays ads via Google AdSense. Third-party vendors, including Google, use cookies to serve ads
            based on your prior visits to this app or other websites. Google's use of advertising cookies enables it
            and its partners to serve ads based on your visit to this site and/or other sites on the Internet. You may
            opt out of personalized advertising by visiting{' '}
            <a
              href="https://www.google.com/settings/ads"
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-amber-600 underline"
            >
              Google Ads Settings
            </a>
            .
          </p>
        </section>

        <section className="rounded-xl border border-amber-200 bg-amber-50 p-4">
          <div className="mb-2 flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-500" />
            <h3 className="text-sm font-bold text-amber-600">Government Non-Affiliation Disclaimer</h3>
          </div>
          <p className="text-sm text-amber-600">
            This app is an independent, unofficial study aid. It is <strong>not affiliated with, endorsed by, or
            officially connected to</strong> the Government of Nepal, the Public Service Commission (Lok Sewa Aayog),
            or any provincial public service commission. All content is for educational purposes only.
          </p>
          <div className="mt-3 flex flex-col gap-2">
            <a
              href="https://psc.gov.np"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-sm font-medium text-forest-500 underline"
            >
              Official PSC website: psc.gov.np <ExternalLink className="h-3.5 w-3.5" />
            </a>
            <a
              href="https://lawcommission.gov.np"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-sm font-medium text-forest-500 underline"
            >
              Nepal Law Commission: lawcommission.gov.np <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>
        </section>

        <p className="pt-2 text-center text-xs text-forest-200">
          Nepal Krishi Lok Sewa Prep · Created by {CREATOR_NAME} · {new Date().getFullYear()}
        </p>
      </div>
    </Modal>
  );
}
