import { Sprout, Info } from 'lucide-react';
import { CREATOR_NAME } from '@/config';

interface HeaderProps {
  onCreatorTap: () => void;
  onInfo: () => void;
}

export function Header({ onCreatorTap, onInfo }: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 safe-top bg-forest-500 text-white shadow-md">
      <div className="mx-auto flex max-w-2xl items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/10 ring-1 ring-white/20">
            <Sprout className="h-5 w-5 text-amber-400" />
          </div>
          <div className="leading-tight">
            <h1 className="font-serif text-[15px] font-bold sm:text-base">Nepal Krishi Lok Sewa Prep</h1>
            <button
              onClick={onCreatorTap}
              className="text-[11px] font-medium text-forest-100 transition-colors active:text-amber-400"
              aria-label={`Creator: ${CREATOR_NAME}`}
            >
              Creator: {CREATOR_NAME}
            </button>
          </div>
        </div>
        <button
          onClick={onInfo}
          className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/10 ring-1 ring-white/20 transition-colors active:bg-white/20"
          aria-label="Info and policies"
        >
          <Info className="h-5 w-5" />
        </button>
      </div>
    </header>
  );
}
