import { Home, BookOpen, ClipboardCheck, Keyboard } from 'lucide-react';
import type { TabKey } from '@/types';

interface BottomNavProps {
  active: TabKey;
  onChange: (tab: TabKey) => void;
}

const TABS: { key: TabKey; label: string; icon: typeof Home }[] = [
  { key: 'home', label: 'Home', icon: Home },
  { key: 'notes', label: 'Notes', icon: BookOpen },
  { key: 'exam', label: 'Mock Exam', icon: ClipboardCheck },
  { key: 'skill', label: 'Skill & GD', icon: Keyboard },
];

export function BottomNav({ active, onChange }: BottomNavProps) {
  return (
    <nav className="sticky bottom-0 z-40 safe-bottom border-t border-forest-100 bg-white shadow-[0_-2px_12px_rgba(0,0,0,0.06)]">
      <div className="mx-auto grid max-w-2xl grid-cols-4">
        {TABS.map(({ key, label, icon: Icon }) => {
          const isActive = active === key;
          return (
            <button
              key={key}
              onClick={() => onChange(key)}
              className="flex flex-col items-center gap-1 py-2.5 transition-colors"
              aria-label={label}
              aria-current={isActive ? 'page' : undefined}
            >
              <Icon
                className={`h-5 w-5 transition-transform ${
                  isActive ? 'scale-110 text-forest-500' : 'text-forest-200'
                }`}
                strokeWidth={isActive ? 2.5 : 2}
              />
              <span
                className={`text-[10px] font-medium leading-none ${
                  isActive ? 'text-forest-500' : 'text-forest-200'
                }`}
              >
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
