import { useEffect, useRef } from 'react';
import { SHOW_ADS, ADSENSE_CLIENT_ID } from '@/config';

interface AdSenseBannerProps {
  slot?: string;
  format?: string;
  className?: string;
}

declare global {
  interface Window {
    adsbygoogle?: unknown[];
  }
}

export function AdSenseBanner({ slot = '0000000000', format = 'auto', className = '' }: AdSenseBannerProps) {
  const ref = useRef<HTMLModElement>(null);

  useEffect(() => {
    if (!SHOW_ADS || !ADSENSE_CLIENT_ID) return;
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({} as never);
    } catch {
      // script not loaded yet — fine, ad just won't render
    }
  }, []);

  if (!SHOW_ADS) return null;

  return (
    <div className={`flex items-center justify-center w-full ${className}`}>
      <div className="w-full overflow-hidden rounded-xl border border-forest-100 bg-cream text-center">
        <p className="pt-2 text-[10px] uppercase tracking-wider text-forest-300">Advertisement</p>
        <ins
          ref={ref}
          className="adsbygoogle block min-h-[90px]"
          style={{ display: 'block' }}
          data-ad-client={ADSENSE_CLIENT_ID}
          data-ad-slot={slot}
          data-ad-format={format}
          data-full-width-responsive="true"
        />
        {ADSENSE_CLIENT_ID.includes('XXXX') && (
          <p className="py-4 text-xs text-forest-300">
            Ad slot — replace <code className="font-mono">ADSENSE_CLIENT_ID</code> with your real publisher ID to serve ads.
          </p>
        )}
      </div>
    </div>
  );
}
