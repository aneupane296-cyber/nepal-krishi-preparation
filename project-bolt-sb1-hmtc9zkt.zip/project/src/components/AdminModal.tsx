import { useState } from 'react';
import { Modal } from './Modal';
import type { MCQ, StudyModule } from '@/types';

interface AdminModalProps {
  open: boolean;
  onClose: () => void;
  onAddNote: (note: StudyModule) => void;
  onAddMcq: (mcq: MCQ) => void;
}

const NOTE_TEMPLATE = JSON.stringify(
  {
    id: 'note-new',
    title: 'New Study Module Title',
    category: 'Agronomy',
    tags: ['tag1'],
    content: 'Write your study content here...',
  },
  null,
  2
);

const MCQ_TEMPLATE = JSON.stringify(
  {
    id: 'mcq-new',
    commission: 'all',
    postLevel: 'officer',
    question: 'Your question here?',
    options: ['Option A', 'Option B', 'Option C', 'Option D'],
    correctIndex: 0,
    explanation: 'Explanation for the correct answer...',
  },
  null,
  2
);

export function AdminModal({ open, onClose, onAddNote, onAddMcq }: AdminModalProps) {
  const [mode, setMode] = useState<'note' | 'mcq'>('note');
  const [text, setText] = useState(NOTE_TEMPLATE);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  function switchMode(m: 'note' | 'mcq') {
    setMode(m);
    setText(m === 'note' ? NOTE_TEMPLATE : MCQ_TEMPLATE);
    setError('');
    setSuccess('');
  }

  function handleSubmit() {
    setError('');
    setSuccess('');
    try {
      const parsed = JSON.parse(text);
      if (mode === 'note') {
        if (!parsed.id || !parsed.title || !parsed.content) {
          throw new Error('Note must have id, title, and content');
        }
        onAddNote(parsed as StudyModule);
        setSuccess(`Added note: "${parsed.title}"`);
      } else {
        if (!parsed.id || !parsed.question || !Array.isArray(parsed.options) || parsed.options.length < 2) {
          throw new Error('MCQ must have id, question, and at least 2 options');
        }
        if (parsed.correctIndex === undefined || parsed.correctIndex < 0 || parsed.correctIndex >= parsed.options.length) {
          throw new Error('correctIndex must be a valid option index');
        }
        onAddMcq(parsed as MCQ);
        setSuccess(`Added MCQ: "${parsed.question}"`);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Invalid JSON');
    }
  }

  return (
    <Modal open={open} onClose={onClose} title="Admin Updater" maxWidth="max-w-lg">
      <p className="mb-3 text-xs text-forest-300">
        Add new study notes or MCQs. Edit the JSON below and tap Save. Content is stored locally on your device.
      </p>

      <div className="mb-3 flex gap-2">
        <button
          onClick={() => switchMode('note')}
          className={`flex-1 rounded-lg py-2 text-sm font-semibold ${
            mode === 'note' ? 'bg-forest-500 text-white' : 'bg-cream text-forest-400 ring-1 ring-forest-50'
          }`}
        >
          Add Note
        </button>
        <button
          onClick={() => switchMode('mcq')}
          className={`flex-1 rounded-lg py-2 text-sm font-semibold ${
            mode === 'mcq' ? 'bg-forest-500 text-white' : 'bg-cream text-forest-400 ring-1 ring-forest-50'
          }`}
        >
          Add MCQ
        </button>
      </div>

      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        spellCheck={false}
        className="h-64 w-full rounded-xl border border-forest-100 bg-cream p-3 font-mono text-xs leading-relaxed text-forest-600 focus:border-forest-400 focus:outline-none focus:ring-2 focus:ring-forest-200"
      />

      {error && (
        <p className="mt-2 rounded-lg bg-red-50 p-2.5 text-xs font-medium text-red-500">{error}</p>
      )}
      {success && (
        <p className="mt-2 rounded-lg bg-forest-50 p-2.5 text-xs font-medium text-forest-500">{success}</p>
      )}

      <button
        onClick={handleSubmit}
        className="mt-3 w-full rounded-xl bg-forest-500 py-2.5 text-sm font-bold text-white shadow-md transition-all active:scale-[0.98] active:bg-forest-600"
      >
        Save &amp; Add
      </button>
    </Modal>
  );
}
