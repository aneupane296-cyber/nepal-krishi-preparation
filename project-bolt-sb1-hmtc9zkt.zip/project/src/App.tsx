import { useState, useCallback } from 'react';
import { Header } from '@/components/Header';
import { BottomNav } from '@/components/BottomNav';
import { FilterBar } from '@/components/FilterBar';
import { InfoModal } from '@/components/InfoModal';
import { AdminModal } from '@/components/AdminModal';
import { HomeTab } from '@/screens/HomeTab';
import { NotesTab } from '@/screens/NotesTab';
import { ExamTab } from '@/screens/ExamTab';
import { SkillTab } from '@/screens/SkillTab';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import type { TabKey, Commission, PostLevel, StudyModule, MCQ } from '@/types';
import { CREATOR_NAME } from '@/config';

function App() {
  const [tab, setTab] = useState<TabKey>('home');
  const [commission, setCommission] = useState<Commission>('all');
  const [postLevel, setPostLevel] = useState<PostLevel>('officer');
  const [infoOpen, setInfoOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [creatorTaps, setCreatorTaps] = useState(0);

  const [completedIds, setCompletedIds] = useLocalStorage<string[]>('nklsp_completed', []);
  const [bookmarkIds, setBookmarkIds] = useLocalStorage<string[]>('nklsp_bookmarks', []);
  const [extraNotes, setExtraNotes] = useLocalStorage<StudyModule[]>('nklsp_notes_custom', []);
  const [extraMcqs, setExtraMcqs] = useLocalStorage<MCQ[]>('nklsp_mcqs_custom', []);

  const handleCreatorTap = useCallback(() => {
    setCreatorTaps((t) => {
      const next = t + 1;
      if (next >= 5) {
        setAdminOpen(true);
        return 0;
      }
      return next;
    });
  }, []);

  function toggleComplete(id: string) {
    setCompletedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  function toggleBookmark(id: string) {
    setBookmarkIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  function addNote(note: StudyModule) {
    setExtraNotes((prev) => [note, ...prev.filter((n) => n.id !== note.id)]);
  }

  function addMcq(mcq: MCQ) {
    setExtraMcqs((prev) => [mcq, ...prev.filter((m) => m.id !== mcq.id)]);
  }

  return (
    <div className="flex min-h-screen flex-col bg-cream">
      <Header onCreatorTap={handleCreatorTap} onInfo={() => setInfoOpen(true)} />

      <FilterBar
        commission={commission}
        postLevel={postLevel}
        onCommissionChange={setCommission}
        onPostLevelChange={setPostLevel}
      />

      <main className="flex-1">
        {tab === 'home' && <HomeTab completedIds={completedIds} onNavigate={setTab} />}
        {tab === 'notes' && (
          <NotesTab
            completedIds={completedIds}
            bookmarkIds={bookmarkIds}
            onToggleComplete={toggleComplete}
            onToggleBookmark={toggleBookmark}
            extraModules={extraNotes}
          />
        )}
        {tab === 'exam' && <ExamTab commission={commission} postLevel={postLevel} extraMcqs={extraMcqs} />}
        {tab === 'skill' && <SkillTab />}
      </main>

      <BottomNav active={tab} onChange={setTab} />

      <InfoModal open={infoOpen} onClose={() => setInfoOpen(false)} />
      <AdminModal
        open={adminOpen}
        onClose={() => setAdminOpen(false)}
        onAddNote={addNote}
        onAddMcq={addMcq}
      />

      <p className="sr-only">Creator: {CREATOR_NAME}</p>
    </div>
  );
}

export default App;
