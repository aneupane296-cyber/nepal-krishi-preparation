import type { StudyModule } from '../types';

export const STUDY_MODULES: StudyModule[] = [
  {
    id: 'const-schedules',
    title: 'Constitution of Nepal — Schedules 5 to 9',
    category: 'Constitution',
    tags: ['constitution', 'schedules', 'federalism'],
    content: `Schedule 5 — List of Federal Legislative Powers
Includes defence, foreign affairs, currency, citizenship, inter-province transport, national highways, large hydropower, standards of higher education, and intellectual property.

Schedule 6 — List of Provincial Legislative Powers
Provincial police, provincial public service, provincial taxes (entertainment, agri. income tax, transport), cooperatives, provincial tourism, and management of provincial forests & wildlife.

Schedule 7 — Concurrent Federal & Provincial Powers
Criminal law, civil law, evidence, electricity, environment, tourism, forestry, education up to secondary level, agriculture (concurrent), and health services.

Schedule 8 — List of Local Level Powers
Municipal police, local taxes (property, house rent), management of local schools & health posts, local markets, local roads, drinking water, and basic agriculture extension.

Schedule 9 — Concurrent Powers of Federal, Provincial & Local
Disaster management, natural resources utilization, ancient monuments, and climate change adaptation.

Key for agriculture: Agriculture is a concurrent subject (Schedule 7 & 9), so provinces legislate on provincial agriculture policy while the federal government sets national policy and standards.`,
  },
  {
    id: 'seeds-act-2045',
    title: 'Seeds Act 2045 BS (1988 AD)',
    category: 'Agri Acts',
    tags: ['seeds', 'act', 'legislation'],
    content: `The Seeds Act 2045 regulates seed production, processing, certification, and trade in Nepal.

Key provisions:
- Established the Seed Quality Control Centre (SQCC).
- Requires variety registration before commercial sale.
- Defines Certified, Improved, and Breeder seed classes.
- Seed certification follows field inspection standards (3 inspections for cereals).
- Penalty for selling uncertified/label-violating seeds: fine up to Rs 5,000 or 3 months imprisonment (original act).
- Seed buffer stock management is a government responsibility.

Seed classes: Breeder → Foundation → Certified (nucleus from NARC).`,
  },
  {
    id: 'plant-protection-act-2064',
    title: 'Plant Protection Act 2064 BS (2007 AD)',
    category: 'Agri Acts',
    tags: ['plant protection', 'quarantine', 'pests'],
    content: `Replaced the 2029 BS Plant Protection Act. Aligns with IPPC (International Plant Protection Convention).

Key provisions:
- Establishes Plant Quarantine Checkpoints at borders and airports.
- Regulates import/export of plants, plant products, and regulated articles.
- Requires Phytosanitary Certificate for import.
- Prohibits entry of quarantine pests (A1) and regulated non-quarantine pests (A2).
- Empowers quarantine officers to inspect, detain, treat, or destroy infested material.
- Pest Risk Analysis (PRA) is mandatory before granting import permit.`,
  },
  {
    id: 'pesticides-act-2076',
    title: 'Pesticides Management Act 2076 BS (2019 AD)',
    category: 'Agri Acts',
    tags: ['pesticides', 'management', 'regulation'],
    content: `Replaced the Pesticides Act 2028 BS. Modernizes pesticide regulation in Nepal.

Key provisions:
- Establishes the Pesticides Management Board under the Ministry of Agriculture.
- Pesticide registration: must be registered before import, manufacture, or sale.
- Classifies pesticides into restricted, banned, and general-use categories.
- Banned pesticides include: DDT, BHC, Chlordane, Aldrin, Dieldrin, Endrin, Heptachlor, Lindane, Mirex, Toxaphene, and organomercury compounds.
- Requires pesticide dealers licence and training.
- Promotes Integrated Pest Management (IPM) as the national strategy.
- Establishes Maximum Residue Limits (MRLs) for food safety.`,
  },
  {
    id: 'right-to-food-act-2075',
    title: 'Right to Food and Food Sovereignty Act 2075 BS (2018 AD)',
    category: 'Agri Acts',
    tags: ['food security', 'rights', 'sovereignty'],
    content: `Implements the fundamental right to food under Article 36 of the Constitution.

Key provisions:
- Every citizen has the right to be free from hunger and to have access to adequate, safe, and nutritious food.
- Government responsibility to ensure food security for vulnerable groups.
- Establishes the Right to Food and Food Sovereignty Council for monitoring.
- Promotes domestic food production and protection of local seeds/genetic resources.
- Requires minimum food reserves at federal, provincial, and local levels.
- Provision for compensation if food security is violated by state action.`,
  },
  {
    id: 'ads-2015-2035',
    title: 'Agriculture Development Strategy (ADS) 2015–2035',
    category: 'Policy',
    tags: ['ads', 'strategy', 'policy'],
    content: `20-year strategic document (2015 to 2035/2072 to 2092 BS), with 10-year action plan.

Vision: "A self-reliant, sustainable, modernized, and commercialized agriculture sector."

Pillars (5):
1. Governance — reforming institutions and service delivery.
2. Productivity — technology, inputs, mechanization.
3. Profitability — value chains, market access.
4. Investment — public-private partnerships.
5. Mechanization — from manual to modern tools.

Targets: 8% annual agricultural growth, reduce poverty, improve food & nutrition security.
Key concept: "Pocket, Block, Zone, Super Zone" approach for commercialization of priority commodities.`,
  },
  {
    id: 'agronomy-seed-tags',
    title: 'Agronomy & Seed Tag Colors',
    category: 'Agronomy',
    tags: ['seed', 'tag', 'colors', 'certification'],
    content: `Seed Certification Tag Colors (Nepal):

White Tag — Breeder Seed (highest genetic purity, produced by NARC/breeder).
Yellow Tag — Foundation Seed (produced from breeder seed; by government farms/registered growers).
Blue Tag — Certified Seed (produced from foundation seed; sold to farmers).
Green Tag — Improved/Truthfully Labeled Seed (declared by producer; not officially certified).

Major cereals: Rice, Wheat, Maize are the staple food grains of Nepal.
Rice growing seasons in Nepal: Asarre Dhan (spring/pre-monsoon, direct seeded), Bhadaiya Dhan (main season/transplanted), Gaiya/Chaiti Dhan (winter/spring irrigated).
Wheat is the 3rd most important staple; sown in Kartik-Mangsir, harvested in Chaitra-Baisakh.
Maize is 2nd in area & production; primarily grown in hills as a rainfed crop.`,
  },
  {
    id: 'soil-ipns',
    title: 'Soil Science & IPNS (Lime/Gypsum Reclamation)',
    category: 'Soil Science',
    tags: ['soil', 'ipns', 'lime', 'gypsum', 'reclamation'],
    content: `Integrated Plant Nutrient System (IPNS):
Combines organic manures, bio-fertilizers, chemical fertilizers, and green manuring to maintain soil health and maximize nutrient-use efficiency.

Soil reaction (pH) of Nepal:
- Terai soils: generally neutral to slightly acidic (pH 5.5–7.0).
- Mid-hills: acidic (pH 4.5–6.0), especially old terraces.
- High Himal: variable, often alkaline in valleys.

Acidic soil reclamation:
- Apply Agricultural LIME (CaCO₃) @ 2–4 t/ha once in 3–4 years.
- Lime raises pH, reduces Al³⁺ and Mn²⁺ toxicity, improves P availability.

Sodic/alkaline soil reclamation (less common in Nepal, but in irrigated pockets):
- Apply GYPSUM (CaSO₄·2H₂O) to replace exchangeable Na⁺ with Ca²⁺.
- Follow with leaching to flush out sodium sulfate.

Problem soils: Acid soils dominate the Nepalese hills; liming is the primary reclamation practice.`,
  },
  {
    id: 'horticulture-hdp',
    title: 'Horticulture: Propagation, HDP, TPS, ZECC',
    category: 'Horticulture',
    tags: ['horticulture', 'propagation', 'hdp', 'tps', 'zecc'],
    content: `Plant Propagation:
- Sexual (seed): used for vegetables, TPS potato, and fruit rootstocks.
- Asexual/Vegetative: Cutting, Layering (air-layering in litchi/lemon), Grafting (mango, citrus), Budding (citrus T-budding), and Tissue Culture (banana, orchids, potato virus-free).

High Density Planting (HDP):
- Planting more trees per unit area than traditional spacing.
- Used in apple, mango, and banana for higher early yield.
- Requires dwarfing rootstocks, canopy management (pruning/training), and fertigation.

TPS (True Potato Seed):
- Botanical seed of potato (not tuber), used to reduce disease carry-over.
- Advantage: 25–30 g TPS replaces 2–2.5 t seed tubers per hectare.

ZECC (Zero Energy Cool Chamber):
- Low-cost structure (brick, sand, bamboo) that uses evaporative cooling.
- Maintains 85–90% RH and 8–12 °C below ambient — no electricity needed.
- Ideal for short-term storage of vegetables and fruits in rural areas.`,
  },
  {
    id: 'plant-protection-ipm',
    title: 'Plant Protection: IPM, Pheromone Lures, Bio-control',
    category: 'Plant Protection',
    tags: ['ipm', 'pheromone', 'biocontrol', 'fungi'],
    content: `Integrated Pest Management (IPM):
A combination of cultural, mechanical, biological, and chemical methods — chemicals are the last resort. Nepal's IPM program was launched in 1993 with Farmer Field Schools (FFS).

Pheromone Lures:
- Use synthetic sex pheromones to attract & trap male insects.
- Common: Helicoverpa (chickpea/tomato fruit borer), Pectinophora (cotton pink bollworm), Spodoptera (armyworm).
- Trap types: Delta trap, funnel trap, light trap.
- Used for monitoring (early warning) and mass trapping.

Bio-control Fungi (entomopathogens):
- Metarhizium anisopliae — effective against termites, white grubs, and rice pests.
- Beauveria bassiana — broad spectrum; controls aphids, borers, and whiteflies.
- Trichoderma viride/harzianum — antagonistic fungus; controls soil-borne pathogens (Fusarium, Pythium, Rhizoctonia) and promotes plant growth.
- Verticillium lecanii — effective against aphids and mealy bugs.

Nepal's 1st bio-pesticide lab: NARC, Khumaltar.`,
  },
  {
    id: 'extension-economics',
    title: 'Extension & Economics: Leagans, Rogers, B/C, NPV',
    category: 'Extension & Economics',
    tags: ['extension', 'leagans', 'rogers', 'economics', 'npv'],
    content: `Extension Models:

Leagans' Model (1962): "Extension is a system of non-formal education for rural people" — based on four elements:
1. Teaching (extending knowledge)
2. Communication (two-way flow)
3. Local leadership
4. Action (behavioral change)

Rogers' Adopter Categories (Diffusion of Innovations):
1. Innovators (2.5%)
2. Early Adopters (13.5%)
3. Early Majority (34%)
4. Late Majority (34%)
5. Laggards (16%)

Farm Economics:
Benefit-Cost Ratio (B/C Ratio):
- B/C = Total Benefits (PV) ÷ Total Costs (PV)
- If B/C > 1, the project is acceptable.

Net Present Value (NPV):
- NPV = Σ [ (Bₜ − Cₜ) / (1+r)ᵗ ] for t=0 to n
- Positive NPV = economically viable.

Internal Rate of Return (IRR): the discount rate where NPV = 0.`,
  },
  {
    id: 'province-flagships',
    title: "All 7 Provinces' Agricultural Flagships",
    category: 'Provinces',
    tags: ['provinces', 'flagship', 'commercial'],
    content: `Nepal's 7 Provinces — Agricultural Flagship/Priority Commodities:

1. Koshi Province: Cardamom (large cardamom), Tea, Ginger, Kiwi (high hills), and Citrus.
2. Madhesh Province: Sugarcane, Mango, Fishery (pisciculture), and Jute.
3. Bagmati Province: Potato, Vegetables, Dairy, and Mushrooms.
4. Gandaki Province: Tea, Coffee, Honey, and Orange (citrus).
5. Lumbini Province: Banana, Industrial crops (sugarcane, cotton), and Vegetables.
6. Karnali Province: Apple (Jumla is famous for organic apple), Off-season vegetables, and Medicinal/AROMATIC herbs (Chiraito, Panch Aunle).
7. Sudurpashchim Province: Rice (Chaite paddy), Turmeric, Ginger, and medicinal herbs.

Note: "Pocket → Block → Zone → Super Zone" approach is used to develop each flagship commodity.`,
  },
  {
    id: 'paper-ii-subjective',
    title: 'Paper II Subjective & JT/JTA Practical Rubrics',
    category: 'Exam Scheme',
    tags: ['paper ii', 'subjective', 'jt', 'jta', 'rubric'],
    content: `Officer (7th/8th Level) Paper II — Subjective:
Tests depth of subject knowledge and analytical ability. Common question types:
1. Short-answer (5 marks): Define a concept or list key points (e.g., "Define IPM and list its components").
2. Long-answer (10 marks): Describe/explain with examples (e.g., "Explain the components of ADS and its major targets").
3. Problem-solving (10 marks): Calculate B/C ratio, Net WPM, or lime requirement.

Scoring rubric focuses on:
- Accuracy of technical content (50%)
- Logical structure & clarity (25%)
- Use of relevant examples/data (15%)
- Completeness (10%)

JT/JTA (4th/5th Level) Practical:
Tests hands-on skills:
- Seed tag identification (white/yellow/blue/green).
- Pheromone trap assembly & placement.
- Soil sampling technique (V or zigzag method).
- Grafting/budding demonstration.
- Fertilizer calculation per hectare.

Scoring rubric: procedure correctness (40%), accuracy of result (30%), safety & cleanliness (15%), time (15%).`,
  },
];
