import { useState, useRef, useEffect } from 'react';
import { Keyboard, RotateCcw, Clock, Users, MessageCircle, Lightbulb, Check, X } from 'lucide-react';

const EN_SAMPLE = 'The future of agriculture depends on the adoption of sustainable farming practices that protect soil health and biodiversity for generations to come.';
const DEVANAGARI_SAMPLE = 'कृषि नेपालको अर्थतन्त्रको मेरुदण्ड हो र किसानहरूले देशको आर्थिक विकासमा महत्वपूर्ण योगदान दिएका छन्।';

type Lang = 'en' | 'ne';

export function SkillTab() {
  const [lang, setLang] = useState<Lang>('en');
  const [input, setInput] = useState('');
  const [seconds, setSeconds] = useState(60);
  const [running, setRunning] = useState(false);
  const [finished, setFinished] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const sample = lang === 'en' ? EN_SAMPLE : DEVANAGARI_SAMPLE;

  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(() => {
        setSeconds((s) => {
          if (s <= 1) {
            if (intervalRef.current) clearInterval(intervalRef.current);
            setRunning(false);
            setFinished(true);
            return 0;
          }
          return s - 1;
        });
      }, 1000);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [running]);

  function startTest() {
    setInput('');
    setSeconds(60);
    setRunning(true);
    setFinished(false);
    setTimeout(() => inputRef.current?.focus(), 50);
  }

  function reset() {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setRunning(false);
    setFinished(false);
    setInput('');
    setSeconds(60);
  }

  function switchLang(l: Lang) {
    if (intervalRef.current) clearInterval(intervalRef.current);
    setLang(l);
    setRunning(false);
    setFinished(false);
    setInput('');
    setSeconds(60);
  }

  const { totalWords, wrongWords, netWpm, accuracy } = calculateWpm(input, sample, finished, 60 - seconds);

  return (
    <div className="mx-auto max-w-2xl space-y-5 px-4 py-4">
      {/* Typing test */}
      <section className="rounded-2xl border border-forest-50 bg-white p-5 shadow-sm">
        <div className="mb-3 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-forest-50 text-forest-500">
            <Keyboard className="h-5 w-5" />
          </div>
          <div className="flex-1">
            <h2 className="font-serif text-base font-bold text-forest-600">Typing Speed Test</h2>
            <p className="text-xs text-forest-300">PSC formula: Net WPM = (Total Words − Wrong Words) ÷ 5</p>
          </div>
        </div>

        {/* Language toggle */}
        <div className="mb-3 flex gap-2">
          <button
            onClick={() => switchLang('en')}
            className={`flex-1 rounded-lg py-2 text-sm font-semibold transition-colors ${
              lang === 'en' ? 'bg-forest-500 text-white' : 'bg-cream text-forest-400 ring-1 ring-forest-50'
            }`}
          >
            English
          </button>
          <button
            onClick={() => switchLang('ne')}
            className={`flex-1 rounded-lg py-2 text-sm font-semibold transition-colors ${
              lang === 'ne' ? 'bg-forest-500 text-white' : 'bg-cream text-forest-400 ring-1 ring-forest-50'
            }`}
          >
            देवनागरी (Devanagari)
          </button>
        </div>

        {/* Timer */}
        <div className="mb-3 flex items-center justify-center gap-2 rounded-xl bg-cream py-2.5">
          <Clock className={`h-5 w-5 ${seconds <= 10 && running ? 'text-red-500' : 'text-forest-400'}`} />
          <span className={`font-mono text-2xl font-bold ${seconds <= 10 && running ? 'text-red-500' : 'text-forest-600'}`}>
            00:{String(seconds).padStart(2, '0')}
          </span>
        </div>

        {/* Sample text */}
        <div className={`mb-3 rounded-xl border border-forest-50 bg-cream p-4 ${lang === 'ne' ? 'text-right' : ''}`} dir={lang === 'ne' ? 'rtl' : 'ltr'}>
          <p className="text-sm leading-relaxed text-forest-400">{sample}</p>
        </div>

        {/* Input */}
        <textarea
          ref={inputRef}
          value={input}
          onChange={(e) => running && setInput(e.target.value)}
          disabled={!running}
          placeholder={running ? 'Start typing here...' : finished ? 'Test complete — see your result below' : 'Press "Start" to begin the 60-second test'}
          className={`h-24 w-full rounded-xl border p-3 text-sm leading-relaxed focus:outline-none ${
            running
              ? 'border-forest-200 bg-white text-forest-600 focus:ring-2 focus:ring-forest-200'
              : 'border-forest-50 bg-cream text-forest-300'
          } ${lang === 'ne' ? 'text-right' : ''}`}
          dir={lang === 'ne' ? 'rtl' : 'ltr'}
        />

        {/* Controls */}
        <div className="mt-3 flex gap-2.5">
          {!running && !finished && (
            <button
              onClick={startTest}
              className="flex-1 rounded-xl bg-forest-500 py-2.5 text-sm font-bold text-white shadow-md transition-all active:scale-[0.98] active:bg-forest-600"
            >
              Start Test
            </button>
          )}
          {running && (
            <button
              onClick={() => {
                if (intervalRef.current) clearInterval(intervalRef.current);
                setRunning(false);
                setFinished(true);
              }}
              className="flex-1 rounded-xl bg-amber-500 py-2.5 text-sm font-bold text-white shadow-md transition-all active:scale-[0.98] active:bg-amber-600"
            >
              Finish Now
            </button>
          )}
          {(finished || running) && (
            <button
              onClick={reset}
              className="flex items-center justify-center gap-1.5 rounded-xl bg-white px-5 py-2.5 text-sm font-semibold text-forest-500 shadow-sm ring-1 ring-forest-50 active:bg-cream"
            >
              <RotateCcw className="h-4 w-4" />
              Reset
            </button>
          )}
        </div>

        {/* Results */}
        {finished && (
          <div className="mt-4 animate-fade-in space-y-3">
            <div className="rounded-xl bg-gradient-to-br from-forest-500 to-forest-600 p-5 text-center text-white">
              <p className="text-xs uppercase tracking-wider text-forest-100">Net WPM</p>
              <p className="font-serif text-4xl font-bold text-amber-400">{netWpm}</p>
              <p className="mt-1 text-xs text-forest-100">
                {totalWords} typed · {wrongWords} wrong · {accuracy}% accuracy
              </p>
            </div>
            <div className="rounded-xl bg-cream p-3 text-xs text-forest-400">
              <p className="font-semibold text-forest-500">Formula applied:</p>
              <p className="mt-1 font-mono">Net WPM = ({totalWords} − {wrongWords}) ÷ 5 = {netWpm}</p>
            </div>
          </div>
        )}
      </section>

      {/* GD Tips */}
      <section className="rounded-2xl border border-forest-50 bg-white p-5 shadow-sm">
        <div className="mb-3 flex items-center gap-2">
          <Users className="h-5 w-5 text-amber-500" />
          <h2 className="font-serif text-base font-bold text-forest-600">Group Discussion (GD) Tips</h2>
        </div>
        <div className="space-y-2.5">
          <Tip text="Initiate the discussion if you can — it shows leadership, but only if you understand the topic well." />
          <Tip text="Listen actively and acknowledge others' points before adding your own." />
          <Tip text="Use data and facts (e.g., agriculture statistics, ADS targets) to support your arguments." />
          <Tip text="Stay on-topic and bring the group back if the discussion drifts." />
          <Tip text="Maintain a calm, respectful tone — never interrupt or dominate." />
          <Tip text="Conclude or summarize the discussion to show analytical ability." />
        </div>
      </section>

      {/* Interview Tips */}
      <section className="rounded-2xl border border-forest-50 bg-white p-5 shadow-sm">
        <div className="mb-3 flex items-center gap-2">
          <MessageCircle className="h-5 w-5 text-amber-500" />
          <h2 className="font-serif text-base font-bold text-forest-600">Interview Tips</h2>
        </div>
        <div className="space-y-2.5">
          <Tip text="Know your subject thoroughly — be ready to explain your B.Sc./M.Sc. thesis or field experience." />
          <Tip text="Prepare for current affairs: recent agricultural policies, budget highlights, and provincial flagships." />
          <Tip text="Be honest — if you don't know an answer, say so gracefully rather than guessing." />
          <Tip text="Dress formally and arrive early. Carry your documents organized in a folder." />
          <Tip text="Practice answering in both Nepali and English — the panel may switch languages." />
          <Tip text="Have thoughtful questions ready about the role or department at the end." />
        </div>
      </section>

      <section className="rounded-2xl border border-amber-100 bg-amber-50 p-4">
        <div className="flex gap-2">
          <Lightbulb className="h-4 w-4 flex-shrink-0 text-amber-500" />
          <p className="text-xs leading-relaxed text-amber-600">
            The PSC skill test assesses both <strong>speed</strong> and <strong>accuracy</strong>. Practice daily with
            both English and Devanagari keyboards to improve your Net WPM.
          </p>
        </div>
      </section>
    </div>
  );
}

function Tip({ text }: { text: string }) {
  return (
    <div className="flex gap-2.5">
      <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-forest-400" />
      <p className="text-sm leading-relaxed text-forest-400">{text}</p>
    </div>
  );
}

function calculateWpm(input: string, sample: string, finished: boolean, elapsed: number) {
  if (!finished) {
    return { totalWords: 0, wrongWords: 0, netWpm: 0, accuracy: 0 };
  }
  const sampleWords = sample.split(/\s+/);
  const inputWords = input.trim().split(/\s+/).filter(Boolean);
  const totalWords = inputWords.length;

  let wrongWords = 0;
  for (let i = 0; i < totalWords; i++) {
    if (inputWords[i] !== sampleWords[i]) {
      wrongWords++;
    }
  }

  const netWpm = Math.max(0, Math.round((totalWords - wrongWords) / 5));
  const accuracy = totalWords > 0 ? Math.round(((totalWords - wrongWords) / totalWords) * 100) : 0;
  void elapsed;
  return { totalWords, wrongWords, netWpm, accuracy };
}
