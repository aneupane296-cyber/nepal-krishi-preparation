import { BookOpen, ClipboardCheck, Keyboard, ChevronRight, GraduationCap, Award, Users } from 'lucide-react';
import { AdSenseBanner } from '@/components/AdSenseBanner';
import { CREATOR_NAME } from '@/config';
import type { TabKey } from '@/types';

interface HomeTabProps {
  completedIds: string[];
  onNavigate: (tab: TabKey) => void;
}

export function HomeTab({ completedIds, onNavigate }: HomeTabProps) {
  const totalModules = 14;
  const progress = Math.round((completedIds.length / totalModules) * 100);

  return (
    <div className="mx-auto max-w-2xl space-y-5 px-4 py-4">
      {/* Progress */}
      <section className="rounded-2xl bg-gradient-to-br from-forest-500 to-forest-600 p-5 text-white shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs font-medium uppercase tracking-wider text-forest-100">Study Progress</p>
            <p className="font-serif text-2xl font-bold">{progress}%</p>
          </div>
          <GraduationCap className="h-10 w-10 text-amber-400" />
        </div>
        <div className="mt-3 h-2.5 w-full overflow-hidden rounded-full bg-white/15">
          <div
            className="h-full rounded-full bg-amber-400 transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
        <p className="mt-2 text-xs text-forest-100">
          {completedIds.length} of {totalModules} modules completed
        </p>
      </section>

      {/* Exam scheme */}
      <section className="rounded-2xl border border-forest-50 bg-white p-5 shadow-sm">
        <h2 className="font-serif text-lg font-bold text-forest-600">Nepal PSC Exam Scheme</h2>
        <p className="mt-1 text-sm text-forest-300">Agriculture Officer &amp; JT/JTA selection process</p>
        <div className="mt-4 space-y-3">
          <ExamStage
            icon={<BookOpen className="h-5 w-5" />}
            title="Paper I — Objective (100 Marks)"
            desc="General knowledge, constitution, and agriculture aptitude. Multiple choice with 20% negative marking."
          />
          <ExamStage
            icon={<ClipboardCheck className="h-5 w-5" />}
            title="Paper II — Subjective (100 Marks)"
            desc="Subject-specific long &amp; short answer questions. Tests analytical depth in agriculture sciences."
          />
          <ExamStage
            icon={<Award className="h-5 w-5" />}
            title="Final Stage — Skill Test + Interview"
            desc="Practical skill assessment and oral interview. For JT/JTA: hands-on practical exam."
          />
        </div>
      </section>

      {/* Quick start */}
      <section>
        <h2 className="mb-2 font-serif text-lg font-bold text-forest-600">Quick Start</h2>
        <div className="grid gap-2.5">
          <QuickStart
            label="Browse Detailed Notes"
            desc="14 free study modules"
            icon={<BookOpen className="h-5 w-5" />}
            onClick={() => onNavigate('notes')}
          />
          <QuickStart
            label="Take a Mock Exam"
            desc="Timed MCQs with negative marking"
            icon={<ClipboardCheck className="h-5 w-5" />}
            onClick={() => onNavigate('exam')}
          />
          <QuickStart
            label="Practice Typing & GD"
            desc="WPM test and interview tips"
            icon={<Keyboard className="h-5 w-5" />}
            onClick={() => onNavigate('skill')}
          />
        </div>
      </section>

      {/* Province preview */}
      <section className="rounded-2xl border border-forest-50 bg-white p-5 shadow-sm">
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-amber-500" />
          <h2 className="font-serif text-base font-bold text-forest-600">All 7 Provinces Covered</h2>
        </div>
        <p className="mt-1 text-sm text-forest-300">
          Filter by Koshi, Madhesh, Bagmati, Gandaki, Lumbini, Karnali, or Sudurpashchim to see province-specific
          agricultural flagships and questions.
        </p>
      </section>

      <AdSenseBanner className="pt-1" />

      <p className="pb-2 text-center text-xs text-forest-200">
        Creator: {CREATOR_NAME} · Free &amp; Copyright-Free Study App
      </p>
    </div>
  );
}

function ExamStage({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="flex gap-3 rounded-xl bg-cream p-3">
      <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg bg-forest-50 text-forest-500">
        {icon}
      </div>
      <div>
        <h3 className="text-sm font-bold text-forest-600">{title}</h3>
        <p className="mt-0.5 text-xs leading-relaxed text-forest-300">{desc}</p>
      </div>
    </div>
  );
}

function QuickStart({
  label,
  desc,
  icon,
  onClick,
}: {
  label: string;
  desc: string;
  icon: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-3 rounded-xl border border-forest-50 bg-white p-4 text-left shadow-sm transition-all active:scale-[0.98] active:border-forest-200"
    >
      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-500">{icon}</div>
      <div className="flex-1">
        <p className="text-sm font-bold text-forest-600">{label}</p>
        <p className="text-xs text-forest-300">{desc}</p>
      </div>
      <ChevronRight className="h-5 w-5 text-forest-200" />
    </button>
  );
}
