import { useMemo, useState, useEffect, useRef } from 'react';
import { Clock, CheckCircle2, XCircle, SkipForward, RotateCcw, Flag, AlertTriangle } from 'lucide-react';
import { MCQS as SEED_MCQS } from '@/data/mcqs';
import type { MCQ, Commission, PostLevel } from '@/types';

interface ExamTabProps {
  commission: Commission;
  postLevel: PostLevel;
  extraMcqs: MCQ[];
}

type Phase = 'intro' | 'active' | 'result';

const EXAM_DURATION = 600; // 10 minutes

export function ExamTab({ commission, postLevel, extraMcqs }: ExamTabProps) {
  const [phase, setPhase] = useState<Phase>('intro');
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [timeLeft, setTimeLeft] = useState(EXAM_DURATION);
  const [currentIdx, setCurrentIdx] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const questions = useMemo(() => {
    const pool = [...extraMcqs, ...SEED_MCQS].filter(
      (m) =>
        (m.commission === commission || m.commission === 'all' || commission === 'all') &&
        m.postLevel === postLevel
    );
    return pool.length > 0 ? pool : [...extraMcqs, ...SEED_MCQS];
  }, [commission, postLevel, extraMcqs]);

  useEffect(() => {
    if (phase === 'active') {
      timerRef.current = setInterval(() => {
        setTimeLeft((t) => {
          if (t <= 1) {
            if (timerRef.current) clearInterval(timerRef.current);
            setPhase('result');
            return 0;
          }
          return t - 1;
        });
      }, 1000);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [phase]);

  function startExam() {
    setAnswers({});
    setTimeLeft(EXAM_DURATION);
    setCurrentIdx(0);
    setPhase('active');
  }

  function selectAnswer(qIndex: number, optionIndex: number) {
    setAnswers((prev) => ({ ...prev, [qIndex]: optionIndex }));
  }

  function finishExam() {
    if (timerRef.current) clearInterval(timerRef.current);
    setPhase('result');
  }

  const score = useMemo(() => {
    let correct = 0;
    let wrong = 0;
    let skipped = 0;
    questions.forEach((q, i) => {
      if (answers[i] === undefined) {
        skipped++;
      } else if (answers[i] === q.correctIndex) {
        correct++;
      } else {
        wrong++;
      }
    });
    const netScore = correct - wrong * 0.2;
    return { correct, wrong, skipped, netScore, total: questions.length };
  }, [questions, answers]);

  const mm = String(Math.floor(timeLeft / 60)).padStart(2, '0');
  const ss = String(timeLeft % 60).padStart(2, '0');

  if (phase === 'intro') {
    return (
      <div className="mx-auto max-w-2xl px-4 py-6">
        <div className="rounded-2xl border border-forest-50 bg-white p-6 shadow-sm">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-forest-50 text-forest-500">
              <Flag className="h-6 w-6" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-bold text-forest-600">Mock Exam</h2>
              <p className="text-xs text-forest-300">{questions.length} questions · 10 min</p>
            </div>
          </div>

          <div className="space-y-3 rounded-xl bg-cream p-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-500" />
              <p className="text-sm font-semibold text-forest-600">Negative Marking: 20%</p>
            </div>
            <p className="text-xs leading-relaxed text-forest-400">
              Net Score = Correct − (Wrong × 0.20). Skipped questions get 0 marks with no deduction. This matches the
              Nepal PSC objective exam pattern.
            </p>
          </div>

          <div className="mt-4 space-y-1.5 text-sm text-forest-400">
            <p>• {questions.length} multiple-choice questions</p>
            <p>• Timer: 10 minutes (auto-submit at 0:00)</p>
            <p>• Detailed explanations after submission</p>
            <p>• Includes Nepali Unicode questions</p>
          </div>

          <button
            onClick={startExam}
            className="mt-5 w-full rounded-xl bg-forest-500 py-3 text-sm font-bold text-white shadow-md transition-all active:scale-[0.98] active:bg-forest-600"
          >
            Start Exam
          </button>
        </div>
      </div>
    );
  }

  if (phase === 'result') {
    return (
      <div className="mx-auto max-w-2xl px-4 py-6">
        <div className="rounded-2xl border border-forest-50 bg-white p-6 shadow-sm">
          <h2 className="font-serif text-lg font-bold text-forest-600">Exam Result</h2>

          <div className="mt-4 rounded-xl bg-gradient-to-br from-forest-500 to-forest-600 p-5 text-center text-white">
            <p className="text-xs uppercase tracking-wider text-forest-100">Net Score</p>
            <p className="font-serif text-4xl font-bold">{score.netScore.toFixed(2)}</p>
            <p className="mt-1 text-xs text-forest-100">out of {score.total}</p>
          </div>

          <div className="mt-4 grid grid-cols-3 gap-2.5">
            <StatBox label="Correct" value={score.correct} color="text-forest-500" bg="bg-forest-50" icon={<CheckCircle2 className="h-4 w-4" />} />
            <StatBox label="Wrong" value={score.wrong} color="text-red-500" bg="bg-red-50" icon={<XCircle className="h-4 w-4" />} />
            <StatBox label="Skipped" value={score.skipped} color="text-forest-300" bg="bg-cream" icon={<SkipForward className="h-4 w-4" />} />
          </div>

          <h3 className="mt-6 mb-2 font-serif text-base font-bold text-forest-600">Answer Review</h3>
          <div className="space-y-3">
            {questions.map((q, i) => {
              const userAns = answers[i];
              const isCorrect = userAns === q.correctIndex;
              const isSkipped = userAns === undefined;
              return (
                <div key={q.id} className="rounded-xl border border-forest-50 p-4">
                  <p className="text-sm font-semibold text-forest-600">
                    {i + 1}. {q.question}
                  </p>
                  <div className="mt-2 space-y-1">
                    {q.options.map((opt: string, oi: number) => {
                      const isAnswer = oi === q.correctIndex;
                      const isUserWrong = oi === userAns && !isCorrect;
                      return (
                        <div
                          key={oi}
                          className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs ${
                            isAnswer
                              ? 'bg-forest-50 font-semibold text-forest-600'
                              : isUserWrong
                              ? 'bg-red-50 text-red-500'
                              : 'text-forest-300'
                          }`}
                        >
                          {isAnswer && <CheckCircle2 className="h-3.5 w-3.5 flex-shrink-0" />}
                          {isUserWrong && <XCircle className="h-3.5 w-3.5 flex-shrink-0" />}
                          <span>{opt}</span>
                        </div>
                      );
                    })}
                  </div>
                  {isSkipped && <p className="mt-1.5 text-xs font-medium text-forest-300">You skipped this question.</p>}
                  <p className="mt-2 rounded-lg bg-amber-50 p-2.5 text-xs leading-relaxed text-amber-600">
                    <span className="font-bold">Explanation: </span>
                    {q.explanation}
                  </p>
                </div>
              );
            })}
          </div>

          <button
            onClick={startExam}
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-forest-500 py-3 text-sm font-bold text-white shadow-md transition-all active:scale-[0.98] active:bg-forest-600"
          >
            <RotateCcw className="h-4 w-4" />
            Retake Exam
          </button>
        </div>
      </div>
    );
  }

  // Active exam
  const q = questions[currentIdx];
  const answeredCount = Object.keys(answers).length;
  const lowTime = timeLeft <= 30;

  return (
    <div className="mx-auto max-w-2xl px-4 py-4">
      {/* Timer & progress */}
      <div className="sticky top-[64px] z-20 -mx-4 mb-4 bg-cream/95 px-4 py-2 backdrop-blur">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className={`h-4 w-4 ${lowTime ? 'text-red-500' : 'text-forest-400'}`} />
            <span className={`font-mono text-lg font-bold ${lowTime ? 'text-red-500' : 'text-forest-600'}`}>
              {mm}:{ss}
            </span>
          </div>
          <span className="text-xs font-medium text-forest-300">
            {currentIdx + 1} / {questions.length} · {answeredCount} answered
          </span>
        </div>
        <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-forest-50">
          <div
            className="h-full rounded-full bg-forest-400 transition-all"
            style={{ width: `${((currentIdx + 1) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="rounded-2xl border border-forest-50 bg-white p-5 shadow-sm">
        <p className="font-serif text-base font-bold text-forest-600">
          {currentIdx + 1}. {q.question}
        </p>
        <div className="mt-4 space-y-2.5">
          {q.options.map((opt: string, oi: number) => {
            const selected = answers[currentIdx] === oi;
            return (
              <button
                key={oi}
                onClick={() => selectAnswer(currentIdx, oi)}
                className={`flex w-full items-center gap-3 rounded-xl border-2 p-3.5 text-left text-sm transition-all active:scale-[0.99] ${
                  selected
                    ? 'border-forest-400 bg-forest-50 font-semibold text-forest-600'
                    : 'border-forest-50 bg-white text-forest-400 active:border-forest-200'
                }`}
              >
                <span
                  className={`flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                    selected ? 'bg-forest-400 text-white' : 'bg-cream text-forest-300'
                  }`}
                >
                  {String.fromCharCode(65 + oi)}
                </span>
                {opt}
              </button>
            );
          })}
        </div>
      </div>

      {/* Nav */}
      <div className="mt-4 flex gap-2.5">
        <button
          onClick={() => setCurrentIdx((i) => Math.max(0, i - 1))}
          disabled={currentIdx === 0}
          className="rounded-xl bg-white px-5 py-2.5 text-sm font-semibold text-forest-500 shadow-sm ring-1 ring-forest-50 transition-colors disabled:opacity-40 active:bg-cream"
        >
          Prev
        </button>
        {currentIdx < questions.length - 1 ? (
          <button
            onClick={() => setCurrentIdx((i) => i + 1)}
            className="flex-1 rounded-xl bg-forest-500 py-2.5 text-sm font-bold text-white shadow-md transition-all active:scale-[0.98] active:bg-forest-600"
          >
            Next
          </button>
        ) : (
          <button
            onClick={finishExam}
            className="flex-1 rounded-xl bg-amber-500 py-2.5 text-sm font-bold text-white shadow-md transition-all active:scale-[0.98] active:bg-amber-600"
          >
            Submit Exam
          </button>
        )}
      </div>

      {currentIdx === questions.length - 1 && (
        <button
          onClick={finishExam}
          className="mt-3 w-full rounded-xl border border-forest-50 py-2.5 text-sm font-medium text-forest-400 transition-colors active:bg-cream"
        >
          Finish &amp; See Results
        </button>
      )}
    </div>
  );
}

function StatBox({
  label,
  value,
  color,
  bg,
  icon,
}: {
  label: string;
  value: number;
  color: string;
  bg: string;
  icon: React.ReactNode;
}) {
  return (
    <div className={`rounded-xl ${bg} p-3 text-center`}>
      <div className={`mb-1 flex items-center justify-center ${color}`}>{icon}</div>
      <p className={`text-xl font-bold ${color}`}>{value}</p>
      <p className="text-[10px] font-medium uppercase tracking-wide text-forest-300">{label}</p>
    </div>
  );
}
