import { useMemo, useState } from 'react';
import { Search, ChevronDown, Check, Bookmark, BookmarkCheck, X } from 'lucide-react';
import { STUDY_MODULES } from '@/data/notes';

interface NotesTabProps {
  completedIds: string[];
  bookmarkIds: string[];
  onToggleComplete: (id: string) => void;
  onToggleBookmark: (id: string) => void;
  extraModules: typeof STUDY_MODULES;
}

export function NotesTab({ completedIds, bookmarkIds, onToggleComplete, onToggleBookmark, extraModules }: NotesTabProps) {
  const [query, setQuery] = useState('');
  const [expanded, setExpanded] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>('all');

  const modules = useMemo(() => [...extraModules, ...STUDY_MODULES], [extraModules]);

  const categories = useMemo(() => {
    const set = new Set(modules.map((m) => m.category));
    return ['all', ...Array.from(set).sort((a: string, b: string) => a.localeCompare(b))];
  }, [modules]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return modules.filter((m) => {
      if (filter !== 'all' && m.category !== filter) return false;
      if (!q) return true;
      return (
        m.title.toLowerCase().includes(q) ||
        m.content.toLowerCase().includes(q) ||
        m.tags.some((t: string) => t.includes(q))
      );
    });
  }, [modules, query, filter]);

  return (
    <div className="mx-auto max-w-2xl px-4 py-4">
      {/* Search */}
      <div className="relative mb-3">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-forest-300" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search notes, topics, tags..."
          className="w-full rounded-xl border border-forest-100 bg-white py-2.5 pl-9 pr-9 text-sm text-forest-600 shadow-sm focus:border-forest-400 focus:outline-none focus:ring-2 focus:ring-forest-200"
        />
        {query && (
          <button
            onClick={() => setQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-forest-300"
            aria-label="Clear search"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Category chips */}
      <div className="no-scrollbar mb-4 flex gap-2 overflow-x-auto pb-1">
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setFilter(c)}
            className={`flex-shrink-0 rounded-full px-3 py-1.5 text-xs font-medium transition-colors ${
              filter === c
                ? 'bg-forest-500 text-white'
                : 'bg-white text-forest-400 ring-1 ring-forest-50'
            }`}
          >
            {c === 'all' ? 'All Topics' : c}
          </button>
        ))}
      </div>

      {/* Modules */}
      <div className="space-y-2.5">
        {filtered.length === 0 && (
          <p className="py-10 text-center text-sm text-forest-300">No notes match your search.</p>
        )}
        {filtered.map((m) => {
          const isOpen = expanded === m.id;
          const isDone = completedIds.includes(m.id);
          const isBookmarked = bookmarkIds.includes(m.id);
          return (
            <div
              key={m.id}
              className={`overflow-hidden rounded-xl border bg-white shadow-sm transition-colors ${
                isOpen ? 'border-forest-200' : 'border-forest-50'
              }`}
            >
              <button
                onClick={() => setExpanded(isOpen ? null : m.id)}
                className="flex w-full items-center gap-3 p-4 text-left"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    {isDone && <Check className="h-4 w-4 flex-shrink-0 text-forest-400" />}
                    <h3 className="text-sm font-bold text-forest-600">{m.title}</h3>
                  </div>
                  <p className="mt-0.5 text-xs text-amber-500">{m.category}</p>
                </div>
                <ChevronDown
                  className={`h-5 w-5 flex-shrink-0 text-forest-300 transition-transform ${isOpen ? 'rotate-180' : ''}`}
                />
              </button>

              {isOpen && (
                <div className="animate-fade-in border-t border-forest-50 px-4 pb-4 pt-3">
                  <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed text-forest-400">
                    {m.content}
                  </pre>
                  <div className="mt-4 flex gap-2.5">
                    <button
                      onClick={() => onToggleComplete(m.id)}
                      className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-semibold transition-colors ${
                        isDone
                          ? 'bg-forest-400 text-white'
                          : 'bg-forest-50 text-forest-500 active:bg-forest-100'
                      }`}
                    >
                      <Check className="h-4 w-4" />
                      {isDone ? 'Completed' : 'Mark Completed'}
                    </button>
                    <button
                      onClick={() => onToggleBookmark(m.id)}
                      className={`flex items-center justify-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold transition-colors ${
                        isBookmarked
                          ? 'bg-amber-50 text-amber-500 ring-1 ring-amber-200'
                          : 'bg-cream text-forest-400 ring-1 ring-forest-50'
                      }`}
                    >
                      {isBookmarked ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
                      {isBookmarked ? 'Saved' : 'Bookmark'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
