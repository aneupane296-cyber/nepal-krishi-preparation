export const SHOW_ADS = true;
export const ADSENSE_CLIENT_ID = 'ca-pub-XXXXXXXXXXXXXXXX';
export const CREATOR_NAME = 'Apar Neupane';
